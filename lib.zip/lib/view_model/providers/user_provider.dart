import 'package:flutter/material.dart';

import '../../core/Firebase-Firestore/firebase_auth_utils.dart';
import '../../core/Firebase-Firestore/firebase_utils.dart';
import '../../core/Firebase-Firestore/models/user_model.dart';

class UserProvider extends ChangeNotifier {
  UserModel? currentUser;

  Future<void> fetchCurrentUser() async {
    String? uid = FirebaseAuthUtils.getCurrentUser()?.uid;
    if (uid != null) {
      currentUser = await FirebaseUtils.getUserFromFireStore(uid);
      notifyListeners();
    }
  }

  void resetUser() {
    currentUser = null;
    notifyListeners();
  }
}

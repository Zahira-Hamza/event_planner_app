class UserModel {
  static const String collectionName = "Users";
  String id;
  String name;
  String email;
  String location;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.location,
  });

  UserModel.fromJson(Map<String, dynamic> json)
    : this(
        id: json['id'],
        name: json['name'],
        email: json['email'],
        location: json['location'] ?? "Cairo, Egypt",
      );

  Map<String, dynamic> toJson() {
    return {"id": id, "name": name, "email": email, "location": location};
  }
}
